package com.example.projectx.ui.AboutUs;

import android.arch.lifecycle.ViewModel;

public class AboutUsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
