package com.example.projectx.ui.FeedBack;

import android.arch.lifecycle.ViewModel;

public class FeedBackViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
