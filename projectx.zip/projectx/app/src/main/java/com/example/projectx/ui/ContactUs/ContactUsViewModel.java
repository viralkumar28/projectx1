package com.example.projectx.ui.ContactUs;

import android.arch.lifecycle.ViewModel;

public class ContactUsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
