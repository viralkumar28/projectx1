package com.example.projectx;

import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TabActivity extends AppCompatActivity {
    TabLayout tab,tab2,tab3;
    ViewPager v,i,e;
    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab);
        v=(ViewPager)findViewById(R.id.view1);
        e=(ViewPager)findViewById(R.id.view2);
        i=(ViewPager)findViewById(R.id.view3);
        tab=(TabLayout)findViewById(R.id.doc);
        tab2=(TabLayout)findViewById(R.id.det);
        tab3=(TabLayout)findViewById(R.id.not);

        fragmentManager = getSupportFragmentManager();


    }
}
