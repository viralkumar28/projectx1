package com.example.projectx;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class move extends AppCompatActivity {
    Button a,b,c,d,e,f;
    ImageView g,h,i,j,k,l;
    Animation blink,bounce,fade,rotate,slide_up,zoomin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move);

        a=(Button)findViewById(R.id.buttonone);
        b=(Button)findViewById(R.id.buttontwo);
        c=(Button)findViewById(R.id.buttonthree);
        d=(Button)findViewById(R.id.buttonfour);
        e=(Button)findViewById(R.id.buttonfive);
        f=(Button)findViewById(R.id.buttonsix);
        g=(ImageView)findViewById(R.id.eye);
        h=(ImageView)findViewById(R.id.ball);
        i=(ImageView)findViewById(R.id.ghost);
        j=(ImageView)findViewById(R.id.circle);
        k=(ImageView)findViewById(R.id.silde);
        l=(ImageView)findViewById(R.id.zoom);

        blink= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.blink);
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                g.setVisibility(View.VISIBLE);
                g.startAnimation(blink);
            }
        });
        bounce= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.bounce);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                h.setVisibility(View.VISIBLE);
                h.startAnimation(bounce);
            }
        });
        fade= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i.setVisibility(View.VISIBLE);
                i.startAnimation(fade);
            }
        });
        rotate= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                j.setVisibility(View.VISIBLE);
                j.startAnimation(rotate);
            }
        });
        slide_up= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_up);
        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                k.setVisibility(View.VISIBLE);
                k.startAnimation(slide_up);
            }
        });
        zoomin= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoomin);
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                l.setVisibility(View.VISIBLE);
                l.startAnimation(zoomin);
            }
        });


    }
}
