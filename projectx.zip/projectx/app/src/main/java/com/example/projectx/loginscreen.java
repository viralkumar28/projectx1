package com.example.projectx;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projectx.ui.home.HomeFragment;

public class loginscreen extends AppCompatActivity {

    private EditText usern, password;
    Button login;

    private TextView createacc,forgot;
    Toast toast;
public static final String MyPREFERENCE="MyPrefs";
public static final String Name="nameKey";
public static final String Password="passwordKey";
SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginscreen);

        usern = (EditText) findViewById(R.id.user);
        password = (EditText) findViewById(R.id.password);
        createacc = (TextView) findViewById(R.id.create);
        login = (Button) findViewById(R.id.one);
        forgot = (TextView) findViewById(R.id.fpss);
        createacc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                android.content.Intent homeIntent = new Intent(loginscreen.this, regscreen.class);
                startActivity(homeIntent);
                finish();

            }
        });
        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent forIntent = new Intent(loginscreen.this, ForgotPasswordActivity.class);
                startActivity(forIntent);
                finish();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                String enter_email = usern.getText().toString();
                sp = getSharedPreferences(MyPREFERENCE, Context.MODE_PRIVATE);
                String na = usern.getText().toString();
                String ps = password.getText().toString();
                SharedPreferences.Editor ed = sp.edit();
                if (enter_email.length() == 0) {
                    usern.setError("Enter Username");
                }
                String enter_password = password.getText().toString();
                if (enter_password.length() == 0) {
                    password.setError("Enter Password");
                } else {
                    ed.putString(Name, na);
                    ed.putString(Password, ps);
                    android.content.Intent homeIntent = new Intent(loginscreen.this, HomeFragment.class);
                    startActivity(homeIntent);
                    finish();
                    Toast.makeText(loginscreen.this, "LOGIN", Toast.LENGTH_LONG).show();

                }

            }
        });

    }


}