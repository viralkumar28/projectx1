package com.example.projectx.ui.Queries;

import android.arch.lifecycle.ViewModel;

public class QueriesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
